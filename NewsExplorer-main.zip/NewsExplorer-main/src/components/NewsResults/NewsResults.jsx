// import React from 'react';
// import './NewsResults.css';

// function NewsResults({ articles = [], isLoading, error }) {
//   if (isLoading) {
//     return <p className="news-results__status">Loading...</p>;
//   }

//   if (error) {
//     return <p className="news-results__status news-results__status--error">{error}</p>;
//   }

//   if (articles.length === 0) {
//     return <p className="news-results__status">No results found.</p>;
//   }

//   return (
//     <section className="news-results">
//       <h2 className="news-results__title">Search Results</h2>
//       <ul className="news-results__list">
//         {articles.map((article, index) => (
//           <li key={index} className="news-results__item">
//             <a
//               href={article.url}
//               target="_blank"
//               rel="noopener noreferrer"
//               className="news-results__link"
//             >
//               <h3 className="news-results__headline">{article.title}</h3>
//               <p className="news-results__summary">{article.description}</p>
//             </a>
//           </li>
//         ))}
//       </ul>
//     </section>
//   );
// }

// export default NewsResults;

import React from 'react';
import './NewsResults.css';
import NewsCard from '../NewsCard/NewsCard';

function NewsResults({
  articles = [],
  isLoading,
  error,
  isLoggedIn,
  onSave,
  onUnsave,
  visibleCards,
  onShowMore,
  showMoreVisible,
}) {
  // Only render the section if there’s loading, error, or articles
  if (!isLoading && !error && articles.length === 0) {
    return null; // Hide the section completely until a search is performed
  }

  if (isLoading) {
    return (
      <section className="news-results">
        <div className="news-results__status_loading">Loading...</div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="news-results news-results--centered">
        <img src="src\components\images\not-found_v1.svg" alt="" />
        <h3 className="news-results__status_title">Nothing Found</h3>
        <p className="news-results__status news-results__status--error">
          Sorry, but nothing matched <br />your search terms.
        </p>
      </section>
    );
  }

  const displayedArticles = articles.slice(0, visibleCards);

  return (
    <section className="news-results">
      {displayedArticles.length > 0 && <h2 className="news-results__title">Search Results</h2>}
      <div className="news-results__list">
        {displayedArticles.map((article, index) => (
          <NewsCard
            key={index}
            article={article}
            isSaved={false} // Placeholder; update with saved state
            onSave={onSave}
            onUnsave={onUnsave}
            isLoggedIn={isLoggedIn}
          />
        ))}
      </div>
      {showMoreVisible && (
        <button className="news-results__show-more" onClick={onShowMore}>
          Show more
        </button>
      )}
    </section>
  );
}

export default NewsResults;