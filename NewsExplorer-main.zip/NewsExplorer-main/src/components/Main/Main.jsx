
import React from 'react';
import './Main.css';
import SearchForm from '../SearchForm/SearchForm';
import Preloader from '../Preloader/Preloader';
import NewsResults from '../NewsResults/NewsResults';

function Main({
  articles,
  isLoading,
  error,
  onShowMore,
  showMoreVisible,
  isLoggedIn,
  onSave,
  onUnsave,
  visibleCards,
  onSearch
}) {
  return (
    <div className="main">
      {/* Hero Section */}
      <section className="main__hero">
        <div className="main__hero-content">
          <h1 className="main__hero-title">What's going on in the world?</h1>
          <p className="main__hero-subtitle">
            Find the latest news on any topic and save them in your personal account.
          </p>
          <SearchForm onSearch={onSearch} /> {/* Sync with App.jsx later */}
        </div>
      </section>
      {/* Article Section */}
      {isLoading ? (
        <Preloader />
      ) : (
        <NewsResults
          articles={articles}
          isLoading={isLoading}
          error={error}
          isLoggedIn={isLoggedIn}
          onSave={onSave}
          onUnsave={onUnsave}
          visibleCards={visibleCards}
          onShowMore={onShowMore}
          showMoreVisible={showMoreVisible}
        />
      )}
      {/* About Section */}
      <section className="main__about">
        <div className="main__about-content">
          <img
            // src="https://images.unsplash.com/photo-1494790108755-2616b612b1f3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
            src='src\components\images\1000132344.jpg'
            alt=""
            className="main__author-image"
          />
          <div className="main__about-text">
            <h2 className="main__about-title">About the author</h2>
            <p className="main__about-description">
              This block describes the project author. Here you should indicate your name, what you do, and which development technologies you know.
            </p>
            <p className="main__about-description">
              You can also talk about your experience with TripleTen, what you learned there, and how you can help potential customers.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Main;