import { mockSavedArticles } from './mockData';

export const getSavedArticles = () => {
  return mockSavedArticles;
};